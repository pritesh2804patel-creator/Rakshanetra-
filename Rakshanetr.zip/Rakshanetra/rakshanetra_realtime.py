import time 
from modules.fetch_latest_threats import fetch_latest_threats 
from modules.intent_classifier import classify_intent 
from modules.threat_mapper import map_threat_type 
from modules.origin_tracer import trace_origin 
from modules.deception_detector import detect_deception 
from modules.zone_resolver import resolve_target_zone 
from modules.response_generator import generate_response 
from modules.decoy_generator import generate_decoy 
 
while True: 
    print("?? Scanning for new threats...") 
    threats = fetch_latest_threats() 
    for query in threats: 
        intent = classify_intent(query) 
        threat = map_threat_type(query) 
        origin = trace_origin(query) 
        deception = detect_deception(query) 
        zone = resolve_target_zone(query) 
        response = generate_response(intent, threat) 
        decoy = generate_decoy(query) 
        print(f"\n?? {query}") 
        print(f"Intent: {intent} | Threat: {threat} | Origin: {origin} | Deception: {deception}") 
        print(f"Response: {response} | Decoy: {decoy} | Zone: {zone}\n") 
