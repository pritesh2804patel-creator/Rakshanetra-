# Rakshanetra: The Third Eye of Bharat
# main.py — ceremonial invocation

from modules.trinetra_core import awaken_trinetra

if __name__ == "__main__":
    print("🔱 Rakshanetra is awakening...")
    awaken_trinetra()
 
